Relevant parts of the website are included.
To view the documentation, open the file index.html

All files required for installation and testing are located in the js folder.
You can use the compact version in the js_compact folder to speed up page loading.
